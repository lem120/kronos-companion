import http from 'node:http'
import crypto from 'node:crypto'
import { homedir, platform } from 'node:os'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

export const UpgradeScripts = []

const KRONOS_APP_IDS = ['be.manythink.kronos2017', 'be.manythink.kronos2017.bridge.dev01']

function uniquePaths(paths) {
  return [...new Set(paths.filter(Boolean).map((value) => String(value)))]
}

function dbCandidates() {
  const home = homedir()
  const os = platform()
  const candidates = []

  if (process.env.KRONOS_DB_PATH) candidates.push(process.env.KRONOS_DB_PATH)

  const addAirStorage = (base) => {
    if (!base) return
    for (const appId of KRONOS_APP_IDS) {
      candidates.push(join(base, appId, 'Local Store', 'db', 'Kronos.rdb'))
      candidates.push(join(base, appId, 'Local Store', 'Kronos.rdb'))
    }
  }

  if (os === 'darwin') {
    addAirStorage(join(home, 'Library', 'Application Support'))
    // Compatibility with older AIR versions.
    addAirStorage(join(home, 'Library', 'Preferences'))
  } else if (os === 'win32') {
    // AIR desktop storage normally lives under %APPDATA% (Roaming).
    // LOCALAPPDATA is also probed for future/runtime-specific configurations.
    addAirStorage(process.env.APPDATA)
    addAirStorage(process.env.LOCALAPPDATA)
    addAirStorage(join(home, 'AppData', 'Roaming'))
    addAirStorage(join(home, 'AppData', 'Local'))
  } else {
    addAirStorage(join(home, '.appdata'))
  }

  return uniquePaths(candidates)
}

function resolveDbPath(configPath = '') {
  const manual = String(configPath || '').trim()
  if (manual) return manual
  const candidates = dbCandidates()
  return candidates.find((candidate) => existsSync(candidate)) || candidates[0] || ''
}

const DEFAULT_CONFIG = Object.freeze({
  host: '127.0.0.1',
  port: 18749,
  pollInterval: 1000,
  dbPath: '',
})

function toInt(value, fallback) {
  const n = Number(value)
  return Number.isFinite(n) ? Math.trunc(n) : fallback
}

function cleanTimer(raw) {
  const order = toInt(raw?.order, 0)
  const id = String(raw?.id ?? '')
  const fallbackLabel = `Timer ${order + 1}`
  const discoveredLabel = raw?.displayedText ?? raw?.displayed_text ?? raw?.name ?? raw?.memoTitle ?? raw?.memo_title ?? raw?.title

  return {
    ...raw,
    id,
    order,
    label: String(discoveredLabel || fallbackLabel),
    running: Boolean(raw?.running),
    paused: Boolean(raw?.paused),
    editing: Boolean(raw?.editing),
    overtime: Boolean(raw?.overtime),
    minutes: String(raw?.minutes ?? '00'),
    seconds: String(raw?.seconds ?? '00'),
  }
}

function stateOf(timer) {
  if (!timer) return 'missing'
  if (timer.editing) return 'editing'
  if (timer.overtime) return 'overtime'
  if (timer.running) return 'running'
  if (timer.paused) return 'paused'
  return 'ready'
}

function timeOf(timer) {
  if (!timer) return '--:--'

  const minutes = Number(String(timer.minutes ?? '0').replace(',', '.'))
  const seconds = Number(String(timer.seconds ?? '0').replace(',', '.'))

  if (!Number.isFinite(minutes) || !Number.isFinite(seconds)) {
    const safeMinutes = String(timer.minutes ?? '00').split(/[.,]/, 1)[0].padStart(2, '0')
    const safeSeconds = String(timer.seconds ?? '00').split(/[.,]/, 1)[0].padStart(2, '0')
    return `${safeMinutes}:${safeSeconds}`
  }

  // Kronos can expose fractional seconds in overtime (for example 01:05.203)
  // while its own Output Screen displays the next whole second (01:06).
  // Normalise the full duration before splitting it back into MM:SS, so a
  // value such as 00:59.800 correctly becomes 01:00 instead of 00:60.
  const totalSeconds = Math.max(0, Math.ceil(minutes * 60 + seconds - 1e-9))
  const wholeMinutes = Math.floor(totalSeconds / 60)
  const wholeSeconds = totalSeconds % 60

  return `${String(wholeMinutes).padStart(2, '0')}:${String(wholeSeconds).padStart(2, '0')}`
}

function stableTimerKey(timerId) {
  return crypto.createHash('sha1').update(String(timerId)).digest('hex').slice(0, 10)
}

export default class KronosBridgeModule {
  constructor(internal) {
    this._ctx = internal
    this.instanceOptions = {
      disableVariableValidation: false,
      disableNewConfigLayout: false,
    }

    this.config = { ...DEFAULT_CONFIG }
    this.timers = []
    this.timerById = new Map()
    this._pollHandle = null
    this._pollPromise = null
    this._structureKey = ''
    this._revision = 0
    this._lastBridgeState = 'starting'
    this._lastDbState = 'starting'
    this._resolvedDbPath = ''
    this.selectedTimerId = ''
  }

  getConfigFields() {
    return [
      {
        type: 'static-text',
        id: 'info',
        width: 12,
        label: 'Kronos Companion',
        value: 'Kronos Companion 1.1.0: timer dinamici, nomi Your Speaking Time e preset Follow Kronos Order per la tastiera Companion.',
      },
      {
        type: 'textinput',
        id: 'host',
        label: 'Host',
        width: 6,
        default: DEFAULT_CONFIG.host,
      },
      {
        type: 'number',
        id: 'port',
        label: 'Porta HTTP',
        width: 3,
        min: 1,
        max: 65535,
        default: DEFAULT_CONFIG.port,
      },
      {
        type: 'number',
        id: 'pollInterval',
        label: 'Aggiornamento (ms)',
        width: 3,
        min: 500,
        max: 5000,
        default: DEFAULT_CONFIG.pollInterval,
      },
      {
        type: 'textinput',
        id: 'dbPath',
        label: 'Database Kronos (vuoto = rilevamento automatico macOS / Windows)',
        width: 12,
        default: '',
      },
    ]
  }

  async init(config) {
    this.config = this._normaliseConfig(config)
    this._setBaseDefinitions()
    await this._pollOnce()
    this._startPolling()
  }

  async destroy() {
    this._stopPolling()
  }

  async configUpdated(config) {
    this.config = this._normaliseConfig(config)
    this._stopPolling()
    await this._pollOnce()
    this._startPolling()
  }

  _normaliseConfig(config) {
    return {
      host: String(config?.host || DEFAULT_CONFIG.host),
      port: Math.min(65535, Math.max(1, toInt(config?.port, DEFAULT_CONFIG.port))),
      pollInterval: Math.min(5000, Math.max(500, toInt(config?.pollInterval, DEFAULT_CONFIG.pollInterval))),
      dbPath: String(config?.dbPath ?? DEFAULT_CONFIG.dbPath),
    }
  }

  _startPolling() {
    this._stopPolling()
    this._pollHandle = setInterval(() => {
      void this._pollOnce()
    }, this.config.pollInterval)
  }

  _stopPolling() {
    if (this._pollHandle) clearInterval(this._pollHandle)
    this._pollHandle = null
  }

  _pollOnce() {
    // Reuse an in-flight poll. Action callbacks wait for it, so a last-second
    // reorder cannot fall through to a stale ID -> position mapping.
    if (this._pollPromise) return this._pollPromise

    this._pollPromise = this._performPoll().finally(() => {
      this._pollPromise = null
    })
    return this._pollPromise
  }

  async _performPoll() {
    try {
      const data = await this._requestJson('GET', '/status')
      const metadata = this._readTimerMetadata(data?.timers)
      const timers = Array.isArray(data?.timers)
        ? data.timers
            .map((raw) => {
              const meta = metadata.get(String(raw?.id ?? ''))
              return cleanTimer(meta ? { ...raw, ...meta } : raw)
            })
            .sort((a, b) => a.order - b.order)
        : []
      const newKey = timers.map((timer) => `${timer.id}:${timer.order}:${timer.label}`).join('|')
      const structureChanged = newKey !== this._structureKey

      this.timers = timers
      this.timerById = new Map(timers.map((timer) => [timer.id, timer]))

      if (!this.selectedTimerId || !this.timerById.has(this.selectedTimerId)) {
        this.selectedTimerId = timers[0]?.id ?? ''
      }

      if (structureChanged) {
        this._structureKey = newKey
        this._revision += 1
        this._rebuildDynamicDefinitions()
      }

      this._lastBridgeState = 'ok'
      this._updateVariables()
      this._ctx.checkFeedbacks(['slot_selected', 'slot_running', 'slot_paused', 'slot_overtime', 'slot_editing', 'timer_running', 'timer_paused', 'timer_overtime', 'timer_editing'])
      this._ctx.updateStatus('ok', `${timers.length} timer · sync ${this.config.pollInterval} ms`)
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      this._ctx.updateStatus('connection_failure', message)
      this._lastBridgeState = `error: ${message}`
      this._updateVariables()
    }
  }

  _readTimerMetadata(statusTimers = []) {
    const statusIds = new Set(
      (Array.isArray(statusTimers) ? statusTimers : [])
        .map((timer) => String(timer?.id ?? ''))
        .filter(Boolean),
    )

    const manualPath = String(this.config.dbPath || '').trim()

    // Companion keeps the previous instance configuration when a module is
    // upgraded. Versions <= 0.1.7 stored the old macOS DEV02 database path as
    // the default value, so after upgrading that stale value can still be
    // present even though the UI now says "empty = auto discovery".
    // Never let a saved/manual path disable discovery: probe it first, then
    // score every database we can find and select the one that matches /status.
    const candidates = uniquePaths([
      ...(manualPath ? [manualPath] : []),
      ...dbCandidates(),
    ]).filter((candidate) => existsSync(candidate))

    let best = null
    const errors = []

    for (const dbPath of candidates) {
      let db
      try {
        db = new DatabaseSync(dbPath, { readOnly: true })
        const rows = db.prepare('SELECT id, memo_title, displayed_text FROM tb_countdown').all()
        const metadata = new Map()
        let overlap = 0
        let namedOverlap = 0
        let namedTotal = 0

        for (const row of rows) {
          const id = String(row?.id ?? '')
          if (!id) continue

          const displayedText = String(row?.displayed_text ?? '').trim()
          const memoTitle = String(row?.memo_title ?? '').trim()
          const label = displayedText || memoTitle

          metadata.set(id, {
            displayedText: label || undefined,
            memoTitle: memoTitle || undefined,
          })

          if (label) namedTotal += 1
          if (statusIds.has(id)) {
            overlap += 1
            if (label) namedOverlap += 1
          }
        }

        // Prefer the database that actually belongs to the timers returned by
        // /status. Named matches are the strongest signal, followed by ID
        // overlap. This avoids selecting a stale/empty AIR database after a
        // Kronos reinstall while preserving the 0.1.7 displayed_text logic.
        const score = statusIds.size
          ? namedOverlap * 1_000_000 + overlap * 10_000 + namedTotal * 100 + rows.length
          : namedTotal * 100 + rows.length

        const candidate = { dbPath, rows, metadata, overlap, namedOverlap, score }
        if (!best || candidate.score > best.score) best = candidate
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        errors.push(`${dbPath}: ${message}`)
      } finally {
        try { db?.close() } catch {}
      }
    }

    if (best) {
      this._resolvedDbPath = best.dbPath
      this._lastDbState = `ok: ${best.rows.length} timer · ${best.namedOverlap}/${statusIds.size || best.rows.length} nomi`
      return best.metadata
    }

    this._resolvedDbPath = manualPath || candidates[0] || resolveDbPath('')
    this._lastDbState = errors.length
      ? `unavailable: ${errors[0]}`
      : 'unavailable: nessun database Kronos trovato'
    return new Map()
  }

  _timerChoices() {
    if (!this.timers.length) {
      return [{ id: '', label: 'Nessun timer disponibile' }]
    }

    return this.timers.map((timer) => ({
      id: timer.id,
      label: timer.label,
    }))
  }

  _slotChoices() {
    if (!this.timers.length) {
      return [{ id: 1, label: 'Posizione 1' }]
    }

    return this.timers.map((timer) => ({
      id: timer.order + 1,
      label: `Posizione ${timer.order + 1} · ${timer.label}`,
    }))
  }

  _slotDropdown(id = 'slot') {
    const choices = this._slotChoices()
    return {
      type: 'dropdown',
      id,
      label: 'Posizione Kronos',
      choices,
      default: choices[0]?.id ?? 1,
      allowCustom: false,
    }
  }

  _timerAtSlot(slot) {
    const target = Math.max(1, toInt(slot, 1))
    return this.timers.find((timer) => timer.order + 1 === target) ?? this.timers[target - 1]
  }

  _timerDropdown(id = 'timerId') {
    const choices = this._timerChoices()
    return {
      type: 'dropdown',
      id,
      label: 'Timer',
      choices,
      default: choices[0]?.id ?? '',
      allowCustom: false,
    }
  }

  _setBaseDefinitions() {
    this._rebuildDynamicDefinitions()
  }

  _rebuildDynamicDefinitions() {
    const timerOption = this._timerDropdown()

    this._ctx.setActionDefinitions({
      select_timer: {
        name: 'Seleziona timer',
        options: [timerOption],
        callback: async (event) => {
          const timerId = String(event.options.timerId ?? '')
          if (!this.timerById.has(timerId)) throw new Error(`Timer ID ${timerId} non trovato`)
          this.selectedTimerId = timerId
          this._updateVariables()
          this._ctx.checkFeedbacks(['slot_selected', 'timer_selected'])
        },
      },
      select_and_play_timer: {
        name: 'Seleziona e avvia timer',
        options: [timerOption],
        callback: async (event) => {
          const timerId = String(event.options.timerId ?? '')
          if (!this.timerById.has(timerId)) throw new Error(`Timer ID ${timerId} non trovato`)
          this.selectedTimerId = timerId
          this._updateVariables()
          this._ctx.checkFeedbacks(['slot_selected', 'timer_selected'])
          await this._executeTimerCommand(timerId, 'play')
        },
      },
      select_and_play_slot: {
        name: 'Posizione Kronos · seleziona e avvia',
        options: [this._slotDropdown()],
        callback: async (event) => {
          await this._executeSlotCommand(event.options.slot, 'play', true)
        },
      },
      selected_timer_command: {
        name: 'Timer selezionato · comando',
        options: [
          {
            type: 'dropdown',
            id: 'command',
            label: 'Comando',
            default: 'toggle',
            choices: [
              { id: 'toggle', label: 'PLAY · Play / Pause / Resume' },
              { id: 'pause', label: 'PAUSE · forza pausa' },
              { id: 'reset', label: 'RESET' },
            ],
          },
        ],
        callback: async (event) => {
          await this._executeSelectedTimerCommand(String(event.options.command ?? 'toggle'))
        },
      },
      timer_command: {
        name: 'Timer · comando (compatibilità)',
        options: [
          timerOption,
          {
            type: 'dropdown',
            id: 'command',
            label: 'Comando',
            default: 'play',
            choices: [
              { id: 'play', label: 'Play / Riprendi' },
              { id: 'pause', label: 'Pause' },
              { id: 'toggle', label: 'Toggle Play/Pause' },
              { id: 'reset', label: 'Reset' },
              { id: 'stop', label: 'Stop / Reset (compatibilità bridge)' },
            ],
          },
        ],
        callback: async (event) => {
          await this._executeTimerCommand(String(event.options.timerId ?? ''), String(event.options.command ?? 'play'))
        },
      },
      refresh_timers: {
        name: 'Aggiorna lista timer adesso',
        options: [],
        callback: async () => {
          await this._pollOnce()
        },
      },
    })

    this._ctx.setFeedbackDefinitions({
      slot_selected: {
        name: 'Posizione Kronos · selezionata',
        type: 'boolean',
        defaultStyle: { bgcolor: 0x1458a6, color: 0xffffff },
        options: [this._slotDropdown()],
        callback: (feedback) => {
          const timer = this._timerAtSlot(feedback.options.slot)
          return Boolean(timer && timer.id === this.selectedTimerId)
        },
      },
      slot_running: {
        name: 'Posizione Kronos · in esecuzione',
        type: 'boolean',
        defaultStyle: { bgcolor: 0x0b8a35, color: 0xffffff },
        options: [this._slotDropdown()],
        callback: (feedback) => Boolean(this._timerAtSlot(feedback.options.slot)?.running),
      },
      slot_paused: {
        name: 'Posizione Kronos · in pausa',
        type: 'boolean',
        defaultStyle: { bgcolor: 0xc87800, color: 0xffffff },
        options: [this._slotDropdown()],
        callback: (feedback) => Boolean(this._timerAtSlot(feedback.options.slot)?.paused),
      },
      slot_overtime: {
        name: 'Posizione Kronos · overtime',
        type: 'boolean',
        defaultStyle: { bgcolor: 0xc41428, color: 0xffffff },
        options: [this._slotDropdown()],
        callback: (feedback) => Boolean(this._timerAtSlot(feedback.options.slot)?.overtime),
      },
      slot_editing: {
        name: 'Posizione Kronos · in modifica',
        type: 'boolean',
        defaultStyle: { bgcolor: 0x555b63, color: 0xffffff },
        options: [this._slotDropdown()],
        callback: (feedback) => Boolean(this._timerAtSlot(feedback.options.slot)?.editing),
      },
      timer_selected: {
        name: 'Timer · selezionato',
        type: 'boolean',
        defaultStyle: { bgcolor: 0x1458a6, color: 0xffffff },
        options: [this._timerDropdown()],
        callback: (feedback) => String(feedback.options.timerId ?? '') === this.selectedTimerId,
      },
      timer_running: {
        name: 'Timer · in esecuzione',
        type: 'boolean',
        defaultStyle: { bgcolor: 0x0b8a35, color: 0xffffff },
        options: [this._timerDropdown()],
        callback: (feedback) => Boolean(this.timerById.get(String(feedback.options.timerId ?? ''))?.running),
      },
      timer_paused: {
        name: 'Timer · in pausa',
        type: 'boolean',
        defaultStyle: { bgcolor: 0xc87800, color: 0xffffff },
        options: [this._timerDropdown()],
        callback: (feedback) => Boolean(this.timerById.get(String(feedback.options.timerId ?? ''))?.paused),
      },
      timer_overtime: {
        name: 'Timer · overtime',
        type: 'boolean',
        defaultStyle: { bgcolor: 0xc41428, color: 0xffffff },
        options: [this._timerDropdown()],
        callback: (feedback) => Boolean(this.timerById.get(String(feedback.options.timerId ?? ''))?.overtime),
      },
      timer_editing: {
        name: 'Timer · in modifica su Kronos',
        type: 'boolean',
        defaultStyle: { bgcolor: 0x555b63, color: 0xffffff },
        options: [this._timerDropdown()],
        callback: (feedback) => Boolean(this.timerById.get(String(feedback.options.timerId ?? ''))?.editing),
      },
    })

    this._rebuildVariableDefinitions()
    this._rebuildPresetDefinitions()
  }

  _rebuildVariableDefinitions() {
    const definitions = {
      bridge_status: { name: 'Kronos Companion · stato bridge' },
      db_status: { name: 'Kronos database · stato' },
      db_path_resolved: { name: 'Kronos database · percorso risolto' },
      host_platform: { name: 'Kronos · piattaforma Companion' },
      timer_count: { name: 'Kronos · numero timer' },
      timer_list_revision: { name: 'Kronos · revisione lista timer' },
      last_sync: { name: 'Kronos · ultima sincronizzazione' },
      selected_timer_id: { name: 'Timer selezionato · ID' },
      selected_timer_label: { name: 'Timer selezionato · nome' },
      selected_timer_time: { name: 'Timer selezionato · tempo' },
      selected_timer_state: { name: 'Timer selezionato · stato' },
    }

    for (const timer of this.timers) {
      const slot = timer.order + 1
      definitions[`slot_${slot}_id`] = { name: `Timer ${slot} · ID stabile` }
      definitions[`slot_${slot}_label`] = { name: `Timer ${slot} · nome/etichetta` }
      definitions[`slot_${slot}_time`] = { name: `Timer ${slot} · tempo` }
      definitions[`slot_${slot}_state`] = { name: `Timer ${slot} · stato` }
      definitions[`slot_${slot}_running`] = { name: `Timer ${slot} · running` }
      definitions[`slot_${slot}_paused`] = { name: `Timer ${slot} · paused` }
      definitions[`slot_${slot}_overtime`] = { name: `Timer ${slot} · overtime` }

      const stableKey = stableTimerKey(timer.id)
      definitions[`timer_${stableKey}_id`] = { name: `${timer.label} · ID stabile` }
      definitions[`timer_${stableKey}_label`] = { name: `${timer.label} · nome/etichetta` }
      definitions[`timer_${stableKey}_time`] = { name: `${timer.label} · tempo` }
      definitions[`timer_${stableKey}_state`] = { name: `${timer.label} · stato` }
      definitions[`timer_${stableKey}_running`] = { name: `${timer.label} · running` }
      definitions[`timer_${stableKey}_paused`] = { name: `${timer.label} · paused` }
      definitions[`timer_${stableKey}_overtime`] = { name: `${timer.label} · overtime` }
    }

    this._ctx.setVariableDefinitions(definitions)
  }

  _rebuildPresetDefinitions() {
    const presets = {}
    const timerPresetIds = []
    const fixedTimerPresetIds = []
    const instanceLabel = String(this._ctx.label || 'Kronos Companion')

    const makeAction = (actionId, options = {}) => ({ actionId, delay: 0, options })
    const makeFeedback = (feedbackId, timerId, style) => ({
      feedbackId,
      options: { timerId },
      style,
      isInverted: false,
    })

    for (const timer of this.timers) {
      const slot = timer.order + 1
      const labelVar = `$(${instanceLabel}:slot_${slot}_label)`
      const timeVar = `$(${instanceLabel}:slot_${slot}_time)`
      const presetId = `slot_${slot}_follow_order`
      timerPresetIds.push(presetId)

      const makeSlotFeedback = (feedbackId, style) => ({
        feedbackId,
        options: { slot },
        style,
        isInverted: false,
      })

      presets[presetId] = {
        type: 'simple',
        name: `Posizione ${slot} · ${timer.label}`,
        style: {
          text: `${labelVar}\n${timeVar}`,
          size: 'auto',
          alignment: 'center:center',
          color: 0xffffff,
          bgcolor: 0x171b20,
          show_topbar: false,
        },
        steps: [{ down: [makeAction('select_and_play_slot', { slot })], up: [] }],
        feedbacks: [
          makeSlotFeedback('slot_selected', { bgcolor: 0x1458a6, color: 0xffffff }),
          makeSlotFeedback('slot_running', { bgcolor: 0x0b8a35, color: 0xffffff }),
          makeSlotFeedback('slot_paused', { bgcolor: 0xc87800, color: 0xffffff }),
          makeSlotFeedback('slot_editing', { bgcolor: 0x555b63, color: 0xffffff }),
          makeSlotFeedback('slot_overtime', { bgcolor: 0xc41428, color: 0xffffff }),
        ],
      }
    }

    // Legacy/fixed-ID presets are kept as an explicit fallback and for users
    // who prefer a timer to remain bound to the same stable ID after reordering.
    for (const timer of this.timers) {
      const stableKey = stableTimerKey(timer.id)
      const labelVar = `$(${instanceLabel}:timer_${stableKey}_label)`
      const timeVar = `$(${instanceLabel}:timer_${stableKey}_time)`
      const presetId = `timer_${stableKey}_fixed_id`
      fixedTimerPresetIds.push(presetId)

      presets[presetId] = {
        type: 'simple',
        name: `${timer.label} · Fixed ID`,
        style: {
          text: `${labelVar}\n${timeVar}`,
          size: 'auto',
          alignment: 'center:center',
          color: 0xffffff,
          bgcolor: 0x171b20,
          show_topbar: false,
        },
        steps: [{ down: [makeAction('select_and_play_timer', { timerId: timer.id })], up: [] }],
        feedbacks: [
          makeFeedback('timer_selected', timer.id, { bgcolor: 0x1458a6, color: 0xffffff }),
          makeFeedback('timer_running', timer.id, { bgcolor: 0x0b8a35, color: 0xffffff }),
          makeFeedback('timer_paused', timer.id, { bgcolor: 0xc87800, color: 0xffffff }),
          makeFeedback('timer_editing', timer.id, { bgcolor: 0x555b63, color: 0xffffff }),
          makeFeedback('timer_overtime', timer.id, { bgcolor: 0xc41428, color: 0xffffff }),
        ],
      }
    }

    presets.control_play = {
      type: 'simple',
      name: 'PLAY',
      style: { text: 'PLAY', size: '24', alignment: 'center:center', color: 0xffffff, bgcolor: 0x0b8a35, show_topbar: false },
      steps: [{ down: [makeAction('selected_timer_command', { command: 'toggle' })], up: [] }],
      feedbacks: [],
    }

    presets.control_pause = {
      type: 'simple',
      name: 'PAUSE',
      style: { text: 'PAUSE', size: '18', alignment: 'center:center', color: 0xffffff, bgcolor: 0xc87800, show_topbar: false },
      steps: [{ down: [makeAction('selected_timer_command', { command: 'pause' })], up: [] }],
      feedbacks: [],
    }

    presets.control_reset = {
      type: 'simple',
      name: 'RESET',
      style: { text: 'RESET', size: '18', alignment: 'center:center', color: 0xffffff, bgcolor: 0x7d252d, show_topbar: false },
      steps: [{ down: [makeAction('selected_timer_command', { command: 'reset' })], up: [] }],
      feedbacks: [],
    }

    const structure = [
      {
        id: 'timers',
        name: 'Timers · Follow Kronos Order',
        definitions: [{
          id: 'timer_list',
          name: 'Timers · Follow Kronos Order',
          description: 'Ogni pulsante rappresenta una posizione Kronos. Se riordini la lista, nome, tempo, stato e comando seguono automaticamente la nuova posizione.',
          type: 'simple',
          presets: timerPresetIds,
        }],
      },
      {
        id: 'controls',
        name: 'Controls',
        definitions: [{
          id: 'timer_controls',
          name: 'Timer Controls',
          description: 'Comandi generici applicati al timer selezionato.',
          type: 'simple',
          presets: ['control_play', 'control_pause', 'control_reset'],
        }],
      },
      {
        id: 'timers_fixed',
        name: 'Timers · Fixed ID (Legacy)',
        definitions: [{
          id: 'timer_list_fixed',
          name: 'Timers · Fixed ID',
          description: 'Modalita precedente: ogni pulsante resta legato allo stesso ID timer anche quando la lista Kronos viene riordinata.',
          type: 'simple',
          presets: fixedTimerPresetIds,
        }],
      },
    ]

    this._ctx.setPresetDefinitions(structure, presets)
  }

  _updateVariables() {
    const values = {
      bridge_status: this._lastBridgeState,
      db_status: this._lastDbState,
      db_path_resolved: this._resolvedDbPath,
      host_platform: platform(),
      timer_count: this.timers.length,
      timer_list_revision: this._revision,
      last_sync: new Date().toLocaleTimeString('it-IT', { hour12: false }),
      selected_timer_id: this.selectedTimerId,
      selected_timer_label: this.timerById.get(this.selectedTimerId)?.label ?? '',
      selected_timer_time: timeOf(this.timerById.get(this.selectedTimerId)),
      selected_timer_state: stateOf(this.timerById.get(this.selectedTimerId)),
    }

    for (const timer of this.timers) {
      const slot = timer.order + 1
      values[`slot_${slot}_id`] = timer.id
      values[`slot_${slot}_label`] = timer.label
      values[`slot_${slot}_time`] = timeOf(timer)
      values[`slot_${slot}_state`] = stateOf(timer)
      values[`slot_${slot}_running`] = timer.running ? 1 : 0
      values[`slot_${slot}_paused`] = timer.paused ? 1 : 0
      values[`slot_${slot}_overtime`] = timer.overtime ? 1 : 0

      const stableKey = stableTimerKey(timer.id)
      values[`timer_${stableKey}_id`] = timer.id
      values[`timer_${stableKey}_label`] = timer.label
      values[`timer_${stableKey}_time`] = timeOf(timer)
      values[`timer_${stableKey}_state`] = stateOf(timer)
      values[`timer_${stableKey}_running`] = timer.running ? 1 : 0
      values[`timer_${stableKey}_paused`] = timer.paused ? 1 : 0
      values[`timer_${stableKey}_overtime`] = timer.overtime ? 1 : 0
    }

    this._ctx.setVariableValues(values)
  }

  async _executeSlotCommand(slotValue, command, select = false) {
    const slot = Math.max(1, toInt(slotValue, 1))

    // Slot semantics: refresh first, then act on whatever timer currently
    // occupies this Kronos position. This is what makes an already placed
    // Companion button follow list reordering without being recreated.
    await this._pollOnce()

    const timer = this._timerAtSlot(slot)
    if (!timer) throw new Error(`Nessun timer in posizione ${slot}`)

    if (select) {
      this.selectedTimerId = timer.id
      this._updateVariables()
      this._ctx.checkFeedbacks(['slot_selected', 'timer_selected'])
    }

    let action = command
    if (command === 'toggle') action = timer.running ? 'pause' : 'play'

    await this._requestJson('POST', `/timer/${slot}/${action}`, { 'X-Kronos-Bridge': '1' })
    await this._pollOnce()
  }

  async _executeSelectedTimerCommand(command) {
    if (!this.selectedTimerId) throw new Error('Nessun timer selezionato')
    await this._executeTimerCommand(this.selectedTimerId, command)
  }

  async _executeTimerCommand(timerId, command) {
    if (!timerId) throw new Error('Nessun timer selezionato')

    // Refresh immediately so a reorder made just before the button press cannot target the wrong timer.
    await this._pollOnce()

    let timer = this.timerById.get(timerId)
    if (!timer) throw new Error(`Timer ID ${timerId} non trovato`)

    let action = command
    if (command === 'toggle') action = timer.running ? 'pause' : 'play'

    const position = timer.order + 1
    await this._requestJson('POST', `/timer/${position}/${action}`, { 'X-Kronos-Bridge': '1' })

    // Pull the post-command state immediately instead of waiting for the next poll tick.
    await this._pollOnce()
  }

  _requestJson(method, path, extraHeaders = {}) {
    return new Promise((resolve, reject) => {
      const req = http.request(
        {
          hostname: this.config.host,
          port: this.config.port,
          path,
          method,
          headers: {
            Accept: 'application/json',
            Connection: 'close',
            ...(method === 'POST' ? { 'Content-Length': '0' } : {}),
            ...extraHeaders,
          },
        },
        (res) => {
          let body = ''
          res.setEncoding('utf8')
          res.on('data', (chunk) => {
            body += chunk
            if (body.length > 1024 * 1024) req.destroy(new Error('Risposta HTTP troppo grande'))
          })
          res.on('end', () => {
            let parsed = {}
            try {
              parsed = body ? JSON.parse(body) : {}
            } catch {
              reject(new Error(`JSON non valido da Kronos (HTTP ${res.statusCode ?? 0})`))
              return
            }

            const code = res.statusCode ?? 0
            if (code < 200 || code >= 300) {
              const detail = parsed?.error ?? parsed?.result ?? body ?? `HTTP ${code}`
              reject(new Error(`Kronos HTTP ${code}: ${detail}`))
              return
            }
            resolve(parsed)
          })
        },
      )

      req.setTimeout(1500, () => req.destroy(new Error('Timeout collegamento a Kronos Bridge')))
      req.on('error', reject)
      req.end()
    })
  }
}
